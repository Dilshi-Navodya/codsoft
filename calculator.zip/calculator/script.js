// Get the display element
const display = document.getElementById('display');

//  clear the display
function clearDisplay() {
    display.innerText = '0';
}

//  delete the last character in the display
function deleteLast() {
    display.innerText = display.innerText.slice(0, -1) || '0';
}

//  append a number to the display
function appendNumber(number) {
    // If the display is showing 0, replace it with the new number
    if (display.innerText === '0') {
        display.innerText = number.toString();
    } else {
        // Otherwise, append the number to the display
        display.innerText += number;
    }
}

//  append an operator to the display
function appendOperator(operator) {
    const lastChar = display.innerText.slice(-1);
    // If the last character is already an operator, replace it
    if (['+', '-', '*', '/', '(', ')'].includes(lastChar) && ['+', '-', '*', '/', '(', ')'].includes(operator)) {
        display.innerText = display.innerText.slice(0, -1) + operator;
    } else {
        // Otherwise, append the operator to the display
        display.innerText += operator;
    }
}

// Function to evaluate the expression in the display
function calculate() {
        display.innerText = eval(display.innerText);
    }

